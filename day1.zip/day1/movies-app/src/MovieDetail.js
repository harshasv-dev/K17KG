import React, { Component } from "react";

class MovieDetail extends Component {
    state = {
        id: 1,
        name: "Hey Ram",
        director: "Kamal Hassan",
        artist: "Shahrukh Khan"
    }
    render() {
        console.log("Render method")
        return (
            <div>
                <h2>Movie ID - {this.state.id} - {this.state.name}</h2>
                <p>Director : {this.state.director}</p>
                <p>Artists : {this.state.artist}</p>
            </div>
        )
    }
}

export default MovieDetail;