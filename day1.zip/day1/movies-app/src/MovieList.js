import React, { Component } from "react";

class MovieList extends Component {
    state = [
        {
            id: 1,
            name: "Hey Ram",
            artists: "Kamal, Sharukh",
            director: "Kamal Hassan"
        },
        {
            id: 2,
            name: "Titanic",
            artists: "Leonardo, Kate",
            director: "Spielberg"
        },
        {
            id: 3,
            name: "Thalapathy",
            artists: "Rajini, Mamooty",
            director: "Mani Ratnam"
        }
    ]

    getMoviesElem = () => {
        const movies = this.state
        const moviesEl = movies.map(m => <p>{m.id} - {m.name}</p>)
        return moviesEl
    }

    getThead = () => {
        return <thead class="table-light">
        <tr>
            <th scope="col">Id</th>
            <th scope="col">Name</th>
            <th scope="col">Artist</th>
            <th scope="col">Director</th>
        </tr>
    </thead>
    }

    getMoviesTable = () => {
        const movies = this.state

        const moviesTable = <table class="table">
            { this.getThead() }
            <tbody>
                { 
                    movies.map(m => {
                        return <tr>
                            <td>{m.id}</td>
                            <td>{m.name}</td>
                            <td>{m.artists}</td>
                            <td>{m.director}</td>
                        </tr>
                    })
                }
            </tbody>
        </table>

        return moviesTable
    }

    render() {
        return this.getMoviesTable()
    }
}

export default MovieList;