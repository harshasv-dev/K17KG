import MovieCmp from "./alt-movies/MovieCmp";
import MovieCollection from "./alt-movies/MovieCollection";
import Counter from "./alt-movies/Counter";

function App() {
  const movie = {
    id: 145,
    name: "Jai Bhim",
    artists: "Suriya",
    director: "TJ Gnanavel"
  }

  return (
    <div className="container">
      <h2>Movies app</h2>
      <Counter />
      {/* <MovieDetail /> */}
      {/* <MovieList />
      <MovieCmp movie={movie} /> */}
      <MovieCollection />
    </div>
  );
}

export default App;
