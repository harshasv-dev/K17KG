import React, { Component } from "react";
import MovieCmp from "./MovieCmp";
import { movies } from "./data";

class MovieCollection extends Component {
    state = {
        movies: movies,
        selctedMovie: null
    }

    getMoviesElem = () => {
        const movies = this.state.movies
        const moviesEl = movies.map(m => <p>{m.id} - {m.name}</p>)
        return moviesEl
    }

    getThead = () => {
        return <thead class="table-light">
        <tr>
            <th scope="col">Id</th>
            <th scope="col">Name</th>
            <th scope="col">Artist</th>
            <th scope="col">Director</th>
            <th scope="col">Actions</th>
        </tr>
    </thead>
    }
    
    showMovieDetails = (sm) => {
        // alert("Show details clicked" + sm.name)
        this.setState({
            ...this.state,
            selectedMovie: sm
        })

    }

    getMoviesTable = () => {
        const movies = this.state.movies

        const moviesTable = <table className="table">
            { this.getThead() }
            <tbody>
                { 
                    movies.map(m => {
                        return <tr>
                            <td>{m.id}</td>
                            <td>{m.name}</td>
                            <td>{m.artists}</td>
                            <td>{m.director}</td>
                            <td>
                                <button className="btn btn-sm pinkBtn" 
                                    onClick={() => this.showMovieDetails(m)}>
                                    Show Details
                                </button>
                            </td>
                        </tr>
                    })
                }
            </tbody>
        </table>

        return moviesTable
    }

    render() {
        console.log("REndering")
        return <div>
            { this.getMoviesTable() }
            { this.state.selectedMovie && <MovieCmp movie={this.state.selectedMovie} /> }
        </div>
    }
}

export default MovieCollection;