export const movies = [
    {
        id: 1,
        name: "Hey Ram",
        artists: "Kamal, Sharukh",
        director: "Kamal Hassan"
    },
    {
        id: 2,
        name: "Titanic",
        artists: "Leonardo, Kate",
        director: "Spielberg"
    },
    {
        id: 3,
        name: "Thalapathy",
        artists: "Rajini, Mamooty",
        director: "Mani Ratnam"
    }
]