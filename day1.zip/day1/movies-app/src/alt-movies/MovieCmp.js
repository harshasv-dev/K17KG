

function MovieCmp(props) {
    const movie = props.movie
    return (
        <div>
            <h2>Movie ID - {movie.id} - {movie.name}</h2>
            <p>Director : {movie.director}</p>
            <p>Artists : {movie.artists}</p>
        </div>
    )
}

export default MovieCmp;