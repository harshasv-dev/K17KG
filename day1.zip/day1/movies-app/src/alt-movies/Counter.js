import React, { Component } from "react";

class Counter extends Component {
    state = {
        count: 0
    }

    increment = () => {
        this.setState({
            ...this.state,
            count: this.state.count + 1
        })
    }

    render() {
        return <div>
            Count : {this.state.count}
            <br/>
            <button onClick={this.increment}>Increment</button>
        </div>
    }
}

export default Counter;